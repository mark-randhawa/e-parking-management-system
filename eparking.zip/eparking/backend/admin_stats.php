<?php
include 'db.php';

header('Content-Type: application/json');

$debug = [];

// Total bookings
$total_bookings_query = $conn->query("SELECT COUNT(*) AS total FROM bookings");
$total_bookings = $total_bookings_query->fetch_assoc()['total'];
$debug['booking_query_success'] = $total_bookings_query ? true : false;

// Total users
$total_users_query = $conn->query("SELECT COUNT(*) AS total FROM users");
$total_users = $total_users_query->fetch_assoc()['total'];
$debug['user_query_success'] = $total_users_query ? true : false;

// Most booked slot
$most_slot_query = $conn->query("SELECT s.slot_name, COUNT(*) AS count FROM bookings b
  JOIN slots s ON b.slot_id = s.id
  GROUP BY b.slot_id ORDER BY count DESC LIMIT 1");
$most_slot = $most_slot_query ? $most_slot_query->fetch_assoc() : null;
$most_booked_slot = $most_slot ? $most_slot['slot_name'] : "None";
$debug['most_slot_query'] = $most_slot;

// Bookings per day
$daily = [];
$daily_query = $conn->query("SELECT DATE(booking_time) AS date, COUNT(*) AS count FROM bookings GROUP BY DATE(booking_time)");
while ($row = $daily_query->fetch_assoc()) {
  $daily[$row['date']] = (int)$row['count'];
}
$debug['daily_result_count'] = count($daily);

echo json_encode([
  'total_bookings' => (int)$total_bookings,
  'total_users' => (int)$total_users,
  'most_booked_slot' => $most_booked_slot,
  'daily_bookings' => $daily,
  'debug' => $debug
]);
?>
